﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            textBox6.ReadOnly = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double number1, number2, number3;
            string operation1 = textBox2.Text;
            string operation2 = textBox4.Text;
            string intermediateReault = "";
            string finalResult = "";

            if (double.TryParse(textBox1.Text, out number1) &&
                double.TryParse(textBox3.Text, out number2) &&
                double.TryParse(textBox5.Text, out number3))
            {

                if ((textBox4.Text == "*" || textBox4.Text == "/"))
                {
                    intermediateReault = PerformOperation(number2, number3, operation2).ToString();
                    finalResult = PerformOperation(Convert.ToDouble(intermediateReault), number1, operation1).ToString();
                }

                else
                {
                    intermediateReault = PerformOperation(number1, number2, operation1).ToString();

                    finalResult = PerformOperation(Convert.ToDouble(intermediateReault), number3, operation2).ToString();
                }

                if (intermediateReault == "NaN")
                {
                    MessageBox.Show("1st Operation Not Correct!", "Error..");
                    textBox2.Focus();
                    textBox2.Clear();
                    return;
                }

                if (finalResult == "NaN")
                {
                    MessageBox.Show("2nd Operation Not correct!", "Error..");
                    textBox4.Focus();
                    textBox4.Clear();
                    return;
                }

                textBox6.Text = finalResult.ToString();
            }

            else
            {
                MessageBox.Show("Enter Correct Numbers!", "Error..");
            }
        }

        private double PerformOperation(double n1, double n2, string operation)
        {
            switch (operation)
            {
                case "+":
                    return n1 + n2;
                case "-":
                    return n1 - n2;
                case "*":
                    return n1 * n2;
                case "/":
                    return n2 != 0 ? n1 / n2 : double.NaN;
                default:
                    return double.NaN;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
