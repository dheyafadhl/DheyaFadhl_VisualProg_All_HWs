﻿namespace WindowsFormsApp1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labDevice1 = new System.Windows.Forms.Label();
            this.labDevice2 = new System.Windows.Forms.Label();
            this.btnRed = new System.Windows.Forms.Button();
            this.btnGreen = new System.Windows.Forms.Button();
            this.btnYellow = new System.Windows.Forms.Button();
            this.btnRes = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labDevice1
            // 
            this.labDevice1.AutoSize = true;
            this.labDevice1.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labDevice1.Location = new System.Drawing.Point(132, 44);
            this.labDevice1.Name = "labDevice1";
            this.labDevice1.Size = new System.Drawing.Size(111, 28);
            this.labDevice1.TabIndex = 0;
            this.labDevice1.Text = "Device 1";
            this.labDevice1.Click += new System.EventHandler(this.Sender_OnClick);
            // 
            // labDevice2
            // 
            this.labDevice2.AutoSize = true;
            this.labDevice2.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labDevice2.Location = new System.Drawing.Point(273, 44);
            this.labDevice2.Name = "labDevice2";
            this.labDevice2.Size = new System.Drawing.Size(111, 28);
            this.labDevice2.TabIndex = 1;
            this.labDevice2.Text = "Device 2";
            this.labDevice2.Click += new System.EventHandler(this.Sender_OnClick);
            // 
            // btnRed
            // 
            this.btnRed.Location = new System.Drawing.Point(24, 100);
            this.btnRed.Name = "btnRed";
            this.btnRed.Size = new System.Drawing.Size(139, 35);
            this.btnRed.TabIndex = 2;
            this.btnRed.Text = "Red";
            this.btnRed.UseVisualStyleBackColor = true;
            this.btnRed.Click += new System.EventHandler(this.Sender_OnClick);
            // 
            // btnGreen
            // 
            this.btnGreen.Location = new System.Drawing.Point(190, 100);
            this.btnGreen.Name = "btnGreen";
            this.btnGreen.Size = new System.Drawing.Size(139, 35);
            this.btnGreen.TabIndex = 3;
            this.btnGreen.Text = "Green";
            this.btnGreen.UseVisualStyleBackColor = true;
            this.btnGreen.Click += new System.EventHandler(this.Sender_OnClick);
            // 
            // btnYellow
            // 
            this.btnYellow.Location = new System.Drawing.Point(356, 100);
            this.btnYellow.Name = "btnYellow";
            this.btnYellow.Size = new System.Drawing.Size(139, 35);
            this.btnYellow.TabIndex = 4;
            this.btnYellow.Text = "Yellow";
            this.btnYellow.UseVisualStyleBackColor = true;
            this.btnYellow.Click += new System.EventHandler(this.Sender_OnClick);
            // 
            // btnRes
            // 
            this.btnRes.Location = new System.Drawing.Point(190, 168);
            this.btnRes.Name = "btnRes";
            this.btnRes.Size = new System.Drawing.Size(139, 35);
            this.btnRes.TabIndex = 5;
            this.btnRes.Text = "..";
            this.btnRes.UseVisualStyleBackColor = true;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(520, 265);
            this.Controls.Add(this.btnRes);
            this.Controls.Add(this.btnYellow);
            this.Controls.Add(this.btnGreen);
            this.Controls.Add(this.btnRed);
            this.Controls.Add(this.labDevice2);
            this.Controls.Add(this.labDevice1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labDevice1;
        private System.Windows.Forms.Label labDevice2;
        private System.Windows.Forms.Button btnRed;
        private System.Windows.Forms.Button btnGreen;
        private System.Windows.Forms.Button btnYellow;
        private System.Windows.Forms.Button btnRes;
    }
}