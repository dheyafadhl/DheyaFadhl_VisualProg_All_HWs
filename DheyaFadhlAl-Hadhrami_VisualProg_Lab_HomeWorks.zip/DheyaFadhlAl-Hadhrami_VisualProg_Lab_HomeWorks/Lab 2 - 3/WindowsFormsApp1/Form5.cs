﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form5 : Form
    {
        double x, y, z;
        public Form5()
        {
            InitializeComponent();

            listBox1.Items.Add("+");
            listBox1.Items.Add("-");
            listBox1.Items.Add("*");
            listBox1.Items.Add("/");
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            button1_Click(sender, e);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form5_Load(sender, e);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            txtRes.ReadOnly = true;
            listBox1.SelectedIndex = 0;
            txtFirst.Text = txtSecond.Text = txtRes.Text = null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                x = Convert.ToDouble(txtFirst.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("First Num is Not Correct!", "Error");
                txtFirst.Focus();
                txtFirst.Clear();
                return;
            }

            try
            {
                y = Convert.ToDouble(txtSecond.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Second Num is Not Correct!", "Error");
                txtSecond.Focus();
                txtSecond.Clear();
                return;
            }

            bool test = false;

            switch (listBox1.SelectedIndex)
            {
                case 0: z = x + y; test = true; break;
                case 1: z = x - y; test = true; break;
                case 2: z = x * y; test = true; break;
                case 3:
                    if (y != 0)
                    {
                        z = x / y;
                        test = true;
                    }
                    else
                    {
                        MessageBox.Show("Can Not Div By 0.", "Exception");
                        txtRes.Clear();
                    }
                    break;
            }
            if (test)
            {
                txtRes.Text = z.ToString();
            }

        }
    }
}
