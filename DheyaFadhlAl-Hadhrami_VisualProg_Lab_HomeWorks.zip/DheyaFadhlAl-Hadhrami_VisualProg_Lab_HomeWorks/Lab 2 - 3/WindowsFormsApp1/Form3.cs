﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Sender_OnClick(object sender, EventArgs e)
        {
            if (sender is Button)
            { 
                if (sender == btnRed)
                {
                    btnRes.BackColor = Color.Red;
                }
                if (sender == btnGreen)
                {
                    btnRes.BackColor = Color.Green;
                }
                if (sender == btnYellow)
                {
                    btnRes.BackColor = Color.Yellow;
                }
            }

            if (sender is Label)
            {
                if (sender == labDevice1)
                {
                    btnRes.Text = labDevice1.Text;
                }
                if (sender == labDevice2)
                {
                    btnRes.Text = labDevice2.Text;
                }
            }
        }
    }
}
