﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Lab_9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            SetEnabled();

            CenterToParent();

            this.Height = btnOpenDown.Top + btnOpenDown.Height + 50;
            groupBox1.Visible = groupBox2.Visible = groupBox3.Visible = btnClose.Visible = false;
            
            Random r = new Random();
            for (int i = 0; i < 10; i++)
            {
                listBox1.Items.Add(r.Next(0, 100).ToString());
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.IndexOf(btnAdd.Text) == -1)
            {
                if (txtAdd.Text.Trim() != "")
                {
                    listBox1.Items.Add(txtAdd.Text.Trim());
                    txtAdd.Clear();
                    txtAdd.Focus();
                }
                else
                {
                    MessageBox.Show("Insert Number To Add it..", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtAdd.Focus();
                }
            }
            else
            {
                txtAdd.Clear();
                txtAdd.Focus();
            }
        }

        private void txtAdd_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar > 58) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void btnMOne_Click(object sender, EventArgs e)
        {
            int count = listBox1.SelectedItems.Count;
            
            for (int i = 0; i < count; i++)
            {   
                if (!listBox2.Items.Contains(listBox1.SelectedItem))
                {
                    listBox2.Items.Add(listBox1.SelectedItem);
                }
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            }
         
        }

        private void btnMAll_Click(object sender, EventArgs e)
        {
            int count = listBox1.Items.Count;

            for (int i = 0; i < count; i++)
            {
                listBox2.Items.Add(listBox1.Items[i].ToString());
            }
            listBox1.Items.Clear();
        }
        private void btnMAllRevers_Click(object sender, EventArgs e)
        {
            int count = listBox2.Items.Count;

            for (int i = 0; i < count; i++)
            {
                listBox1.Items.Add(listBox2.Items[i].ToString());
            }
            listBox2.Items.Clear();

        }


        public static bool IsPrime(int number)
        {
            if (number <= 1)
            {
                return false;
            }

            for (int i = 2; i <= Math.Sqrt(number); i++)
            {
                if (number % i == 0)
                {
                    return false;
                }
            }

            return true;
        }

        private void rdEven_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.ClearSelected();
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                if (Convert.ToInt32(listBox1.Items[i]) % 2 == 0)
                {
                    listBox1.SetSelected(i, true);
                }
            }
        }

        private void rdOdd_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.ClearSelected();

            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                if (Convert.ToInt32(listBox1.Items[i]) % 2 != 0)
                {
                    listBox1.SelectedIndex = i;
                }
            }
        }

        private void rdPrime_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.ClearSelected();
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                if (IsPrime(Convert.ToInt32(listBox1.Items[i].ToString())))
                {
                    listBox1.SetSelected(i, true);
                }
            }
        }

        private void btnOpenDown_Click(object sender, EventArgs e)
        {
            if (btnOpenDown.Text == "v")
            {
                Height = btnClose.Top + btnClose.Height + 50;
                btnOpenDown.Text = "^";
                groupBox1.Visible = groupBox2.Visible = groupBox3.Visible = btnClose.Visible = true;
            }
            else
            {
                groupBox1.Visible = groupBox2.Visible = groupBox3.Visible = btnClose.Visible = false;
                Height = btnOpenDown.Top + btnOpenDown.Height + 50;
                btnOpenDown.Text = "v";
            }
        }


        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            sort(listBox1);
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            sort(listBox2);
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            revers(listBox1);
        }
        private void sort(ListBox l)
        {
            int size = l.Items.Count;
            
            for (int i = 0; i < size;i++)
            {
                for (int j = 0; j < size; j++)
                {
                    if (Convert.ToInt32(l.Items[i]) > Convert.ToInt32(l.Items[j]))
                    {
                        string str = l.Items[i].ToString();
                        l.Items[i] = l.Items[j];
                        l.Items[j] = str;
                    }
                }
            }
        }

        private void revers(ListBox l)
        {
            int size = l.Items.Count;
            
            if (size != -1)
            {
                for (int i = size - 1; i >= 0; i--)
                {
                    l.Items.Add(l.Items[i]);
                    l.Items.Remove(l.Items[i]);
                }
            }
        }

        private void DelSelectedItem(ListBox l)
        {
            if (l.SelectedIndex != -1)
            {
                int n = l.SelectedIndex;

                l.Items.RemoveAt(l.SelectedIndex);

                if (l.SelectedIndex != -1)
                {
                    l.SelectedIndex = n;
                }
            }
        }

        private void SetEnabled()
        {
            btnMOne.Enabled = radioButton5.Enabled = btnSelectedItemsCount.Enabled = listBox1.SelectedIndex > -1;
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            int count = listBox1.Items.Count;
            if (count != -1)
            {
                for (int i = count - 1; i >= 0; i--)
                {
                    listBox2.Items.Add(listBox1.Items[i].ToString());
                }
                listBox1.Items.Clear();
            }
        }

        private void btnG1DelOne_Click(object sender, EventArgs e)
        {
            DelSelectedItem(listBox1);
        }

        private void btnG1DelAll_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void btnG2DelOne_Click(object sender, EventArgs e)
        {
            DelSelectedItem(listBox2);
        }

        private void btnG2DelAll_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            revers(listBox2);
        }

        private void btnSelectItem_Click(object sender, EventArgs e)
        {
            if (txtSelectItem.Text != "")
            {
                if (listBox1.Items.Contains(txtSelectItem.Text))
                {
                    listBox1.SelectedItems.Add(txtSelectItem.Text);
                }
            }
        }

        private void btnUnSelectItem_Click(object sender, EventArgs e)
        {
            if (txtUnSelectItem.Text != "")
            {
                if (listBox1.Items.Contains(txtUnSelectItem.Text))
                {
                    listBox1.SelectedItems.Remove(txtUnSelectItem.Text);
                }
            }
        }

        private void btnUnSelectIndex_Click(object sender, EventArgs e)
        {
            if (txtUnSelectIndex.Text != "")
            {
                listBox1.SelectedItems.Remove(listBox1.Items[Convert.ToInt32(txtUnSelectIndex.Text)]);
            }
        }

        private void rdSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            int size = listBox1.Items.Count;
            for (int i = 0; i < size; i++)
            {
                listBox1.SelectedItems.Add(listBox1.Items[i]);
            }
        }

        private void rdUnSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.SelectedItems.Clear();
        }

        private void btnItemsCount_Click(object sender, EventArgs e)
        {
            int count = 0;
            
            foreach (var item in listBox1.Items)
            {
                ++count;
            }

            txtItemsCount.Text = count.ToString();
        }

        private void btnSelectedItemsCount_Click(object sender, EventArgs e)
        {
            int count = 0;

            foreach (var item in listBox1.SelectedItems)
            {
                ++count;
            }

            txtSelectedItemsCount.Text = count.ToString();
        }

        private void btnUnSelectedItemsCount_Click(object sender, EventArgs e)
        {
            int count = 0;

            foreach (var item in listBox1.Items)
            {
                if (!listBox1.SelectedItems.Contains(item))
                {
                    ++count;
                }
            }

            txtUnSelectedItemsCount.Text = count.ToString();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetEnabled();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
