﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_9
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("+");
            comboBox1.Items.Add("-");
            comboBox1.Items.Add("*");
            comboBox1.Items.Add("/");
            comboBox1.SelectedIndex = 0;
            
            comboBox2.Items.Add("+");
            comboBox2.Items.Add("-");
            comboBox2.Items.Add("*");
            comboBox2.Items.Add("/");
            comboBox2.SelectedIndex = 0;


            SetEnabled();

            textBox3.ReadOnly = textBox4.ReadOnly = true;

            this.CenterToParent();

            Height = btnClose.Top + btnClose.Height + 50;
            groupBox1.Visible = false;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 47 || e.KeyChar > 58) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Enter The Frist Number..", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Focus();
            }

            else if (textBox2.Text == "")
            {
                MessageBox.Show("Enter The Second Number..", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox2.Focus();
            }
            else
            {
                double first = Convert.ToDouble(textBox1.Text.Trim());
                double second = Convert.ToDouble(textBox2.Text.Trim());

                if (comboBox1.SelectedIndex == 0)
                {
                    textBox3.Text = (first + second).ToString();
                }
                else if(comboBox1.SelectedIndex == 1)
                {
                    textBox3.Text = (first - second).ToString();
                }
                else if(comboBox1.SelectedIndex == 2)
                {
                    textBox3.Text = (first * second).ToString();
                }
                else if(comboBox1.SelectedIndex == 3)
                {
                    if (textBox2.Text == "0")
                    {
                        MessageBox.Show("Can't Div By 0..", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBox2.Clear();
                        textBox2.Focus();
                    }
                    else
                    {
                        textBox3.Text = (first / second).ToString();
                    }
                }
                        
                listBox1.Items.Add(textBox1.Text);
                listBox2.Items.Add(comboBox1.SelectedItem);
                listBox3.Items.Add(textBox2.Text);
                listBox4.Items.Add(textBox3.Text);
            }

        }

        private void Select(object sender) {
            listBox1.SelectedIndex = listBox2.SelectedIndex = listBox3.SelectedIndex = listBox4.SelectedIndex = ((ListBox)sender).SelectedIndex;
        }

        private void SetEnabled()
        {
            btnDel.Enabled = btnEdit.Enabled = listBox1.SelectedIndex > -1;
        }

        private void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            Select(sender);
            SetEnabled();
        }
        private void btnDel_Click(object sender, EventArgs e)
        {
            int n = listBox1.SelectedIndex;

            listBox1.Items.Remove(listBox1.Items[n]);
            listBox2.Items.Remove(listBox2.Items[n]);
            listBox3.Items.Remove(listBox3.Items[n]);
            listBox4.Items.Remove(listBox4.Items[n]);
        
        }

        private void btnDelAll_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listBox4.Items.Clear();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            Height = groupBox1.Top + groupBox1.Height + 50;
            groupBox1.Visible = true;

            textBox6.Text = listBox1.SelectedItem.ToString();
            comboBox2.SelectedItem = listBox2.SelectedItem;

            textBox5.Text = listBox3.SelectedItem.ToString();
            textBox4.Text = listBox4.SelectedItem.ToString();
        }

        private void btnCalcSub_Click(object sender, EventArgs e)
        {
            if (textBox6.Text == "")
            {
                textBox6.Focus();
            }

            else if (textBox5.Text == "")
            {
                textBox5.Focus();
            }
            else
            {
                double first = Convert.ToDouble(textBox6.Text.Trim());
                double second = Convert.ToDouble(textBox5.Text.Trim());

                if (comboBox2.SelectedIndex == 0)
                {
                    textBox4.Text = (first + second).ToString();
                }
                else if (comboBox2.SelectedIndex == 1)
                {
                    textBox4.Text = (first - second).ToString();
                }
                else if (comboBox2.SelectedIndex == 2)
                {
                    textBox4.Text = (first * second).ToString();
                }
                else if (comboBox2.SelectedIndex == 3)
                {
                    if (textBox5.Text == "0")
                    {
                        //MessageBox.Show("Can't Div By 0..", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBox5.Clear();
                        textBox5.Focus();
                    }
                    else
                    {
                        textBox4.Text = (first / second).ToString();
                    }
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (textBox6.Text.Trim() == "" && textBox5.Text.Trim() == "")
            {
                btnDel_Click(sender, e);
                btnCancel_Click(sender, e);
            }
            else
            {
                btnCalcSub_Click(sender, e);

                listBox1.Items[listBox1.SelectedIndex] = textBox6.Text;
                listBox2.Items[listBox2.SelectedIndex] = comboBox2.SelectedItem;
                listBox3.Items[listBox3.SelectedIndex] = textBox5.Text;
                listBox4.Items[listBox4.SelectedIndex] = textBox4.Text;

                btnCancel_Click(sender, e);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            textBox6.Clear();
            comboBox2.SelectedIndex = 0;
            textBox5.Clear();
            textBox4.Clear();

            groupBox1.Visible = false;
            Height = btnClose.Top + btnClose.Height + 50;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if ((MessageBox.Show ("Are You sure..!", "End The Program", MessageBoxButtons.YesNo, MessageBoxIcon.Question)) == DialogResult.No)
            {
                e.Cancel = true;
            } 
        }
    }
}
