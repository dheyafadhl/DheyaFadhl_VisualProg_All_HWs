﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_9
{
    public partial class Form2 : Form
    {

        private string[] s = new string[4];
        public Form2()
        {
            InitializeComponent();
        }
        private void select(object sender)
        {
            listBox2.SelectedIndex = listBox3.SelectedIndex = listBox1.SelectedIndex = listBox4.SelectedIndex = ((ListBox)sender).SelectedIndex;

        }
        private void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            select(sender);
            SetEnabled();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != null && textBox2.Text != null && textBox3.Text != null && (radioButton1.Checked == true || radioButton2.Checked == true))
            {
                listBox1.Items.Add(textBox1.Text);
                listBox2.Items.Add(textBox2.Text);
                listBox3.Items.Add(textBox3.Text);
                if (radioButton1.Checked)
                {
                    listBox4.Items.Add(radioButton1.Text);
                }
                if (radioButton2.Checked)
                {
                    listBox4.Items.Add(radioButton2.Text);
                    }
            }
            else
            {
                MessageBox.Show("Enter ALL INFO Please..");
            }


        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 47 || e.KeyChar > 58) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int n = listBox1.SelectedIndex;
            listBox1.Items.Remove(listBox1.Items[n]);
            listBox2.Items.Remove(listBox2.Items[n]);
            listBox3.Items.Remove(listBox3.Items[n]);
            listBox4.Items.Remove(listBox4.Items[n]);
            if (listBox1.SelectedIndex != 1)
            {
                listBox1.SelectedIndex = n;
            }

            SetEnabled();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listBox4.Items.Clear();
            SetEnabled();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            CenterToParent();

            Height = button5.Top + button5.Height + 50;
            SetEnabled();
        }

        private void SetEnabled()
        {
            button4.Enabled = listBox1.SelectedIndex > -1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox6.Text = listBox1.SelectedItem.ToString();
            textBox5.Text = listBox2.SelectedItem.ToString();
            textBox4.Text = listBox3.SelectedItem.ToString();

            if (radioButton1.Checked)
            {
                radioButton4.Checked = true;
            }
            else
            {
                radioButton3.Checked = true;
            }

            Height = groupBox1.Top + groupBox1.Height + 50;
            groupBox1.Visible = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            listBox1.Items[listBox1.SelectedIndex] = textBox6.Text;
            listBox2.Items[listBox1.SelectedIndex] = textBox5.Text;
            listBox3.Items[listBox1.SelectedIndex] = textBox4.Text;

            if (radioButton4.Checked)
            {
                listBox4.Items[listBox1.SelectedIndex] = radioButton4.Text;
            }
            else
            {
                listBox4.Items[listBox1.SelectedIndex] = radioButton3.Text;
            }
            Height = button5.Top + button5.Height + 50;
            groupBox1.Visible = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Height = button5.Top + button5.Height + 50;
            groupBox1.Visible = false;
            SetEnabled();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
