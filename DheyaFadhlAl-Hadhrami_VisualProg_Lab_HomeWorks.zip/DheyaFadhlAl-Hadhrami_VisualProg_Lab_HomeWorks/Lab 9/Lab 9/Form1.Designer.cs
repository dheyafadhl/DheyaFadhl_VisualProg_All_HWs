﻿namespace Lab_9
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtAdd = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnMAllRevers = new System.Windows.Forms.Button();
            this.rdPrime = new System.Windows.Forms.RadioButton();
            this.rdOdd = new System.Windows.Forms.RadioButton();
            this.rdEven = new System.Windows.Forms.RadioButton();
            this.btnMAll = new System.Windows.Forms.Button();
            this.btnMOne = new System.Windows.Forms.Button();
            this.btnOpenDown = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnG1DelAll = new System.Windows.Forms.Button();
            this.btnG1DelOne = new System.Windows.Forms.Button();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnG2DelAll = new System.Windows.Forms.Button();
            this.btnG2DelOne = new System.Windows.Forms.Button();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnUnSelectedItemsCount = new System.Windows.Forms.Button();
            this.txtUnSelectedItemsCount = new System.Windows.Forms.TextBox();
            this.btnSelectedItemsCount = new System.Windows.Forms.Button();
            this.txtSelectedItemsCount = new System.Windows.Forms.TextBox();
            this.btnItemsCount = new System.Windows.Forms.Button();
            this.txtItemsCount = new System.Windows.Forms.TextBox();
            this.rdUnSelectAll = new System.Windows.Forms.RadioButton();
            this.rdSelectAll = new System.Windows.Forms.RadioButton();
            this.btnUnSelectIndex = new System.Windows.Forms.Button();
            this.btnUnSelectItem = new System.Windows.Forms.Button();
            this.btnSelectItem = new System.Windows.Forms.Button();
            this.txtUnSelectIndex = new System.Windows.Forms.TextBox();
            this.txtUnSelectItem = new System.Windows.Forms.TextBox();
            this.txtSelectItem = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtAdd
            // 
            this.txtAdd.Location = new System.Drawing.Point(264, 31);
            this.txtAdd.Name = "txtAdd";
            this.txtAdd.Size = new System.Drawing.Size(272, 24);
            this.txtAdd.TabIndex = 0;
            this.txtAdd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdd_KeyPress);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(485, 78);
            this.listBox1.Name = "listBox1";
            this.listBox1.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listBox1.Size = new System.Drawing.Size(207, 180);
            this.listBox1.TabIndex = 1;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 16;
            this.listBox2.Location = new System.Drawing.Point(83, 78);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(207, 180);
            this.listBox2.TabIndex = 2;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(178, 31);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 24);
            this.btnAdd.TabIndex = 3;
            this.btnAdd.Text = "اضافة";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(557, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "ادخــــل العدد";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnMAllRevers);
            this.panel1.Controls.Add(this.rdPrime);
            this.panel1.Controls.Add(this.rdOdd);
            this.panel1.Controls.Add(this.rdEven);
            this.panel1.Controls.Add(this.btnMAll);
            this.panel1.Controls.Add(this.btnMOne);
            this.panel1.Location = new System.Drawing.Point(296, 78);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(183, 180);
            this.panel1.TabIndex = 5;
            // 
            // btnMAllRevers
            // 
            this.btnMAllRevers.Location = new System.Drawing.Point(95, 147);
            this.btnMAllRevers.Name = "btnMAllRevers";
            this.btnMAllRevers.Size = new System.Drawing.Size(75, 24);
            this.btnMAllRevers.TabIndex = 10;
            this.btnMAllRevers.Text = ">>";
            this.btnMAllRevers.UseVisualStyleBackColor = true;
            this.btnMAllRevers.Click += new System.EventHandler(this.btnMAllRevers_Click);
            // 
            // rdPrime
            // 
            this.rdPrime.AutoSize = true;
            this.rdPrime.Location = new System.Drawing.Point(74, 112);
            this.rdPrime.Name = "rdPrime";
            this.rdPrime.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.rdPrime.Size = new System.Drawing.Size(56, 21);
            this.rdPrime.TabIndex = 9;
            this.rdPrime.TabStop = true;
            this.rdPrime.Text = "اولي";
            this.rdPrime.UseVisualStyleBackColor = true;
            this.rdPrime.CheckedChanged += new System.EventHandler(this.rdPrime_CheckedChanged);
            // 
            // rdOdd
            // 
            this.rdOdd.AutoSize = true;
            this.rdOdd.Location = new System.Drawing.Point(70, 81);
            this.rdOdd.Name = "rdOdd";
            this.rdOdd.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.rdOdd.Size = new System.Drawing.Size(60, 21);
            this.rdOdd.TabIndex = 8;
            this.rdOdd.TabStop = true;
            this.rdOdd.Text = "فردي";
            this.rdOdd.UseVisualStyleBackColor = true;
            this.rdOdd.CheckedChanged += new System.EventHandler(this.rdOdd_CheckedChanged);
            // 
            // rdEven
            // 
            this.rdEven.AutoSize = true;
            this.rdEven.Location = new System.Drawing.Point(67, 50);
            this.rdEven.Name = "rdEven";
            this.rdEven.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.rdEven.Size = new System.Drawing.Size(63, 21);
            this.rdEven.TabIndex = 7;
            this.rdEven.TabStop = true;
            this.rdEven.Text = "زوجي";
            this.rdEven.UseVisualStyleBackColor = true;
            this.rdEven.CheckedChanged += new System.EventHandler(this.rdEven_CheckedChanged);
            // 
            // btnMAll
            // 
            this.btnMAll.Location = new System.Drawing.Point(14, 147);
            this.btnMAll.Name = "btnMAll";
            this.btnMAll.Size = new System.Drawing.Size(75, 24);
            this.btnMAll.TabIndex = 5;
            this.btnMAll.Text = "<<";
            this.btnMAll.UseVisualStyleBackColor = true;
            this.btnMAll.Click += new System.EventHandler(this.btnMAll_Click);
            // 
            // btnMOne
            // 
            this.btnMOne.Location = new System.Drawing.Point(55, 8);
            this.btnMOne.Name = "btnMOne";
            this.btnMOne.Size = new System.Drawing.Size(75, 24);
            this.btnMOne.TabIndex = 4;
            this.btnMOne.Text = "<";
            this.btnMOne.UseVisualStyleBackColor = true;
            this.btnMOne.Click += new System.EventHandler(this.btnMOne_Click);
            // 
            // btnOpenDown
            // 
            this.btnOpenDown.Location = new System.Drawing.Point(83, 267);
            this.btnOpenDown.Name = "btnOpenDown";
            this.btnOpenDown.Size = new System.Drawing.Size(75, 30);
            this.btnOpenDown.TabIndex = 6;
            this.btnOpenDown.Text = "v";
            this.btnOpenDown.UseVisualStyleBackColor = true;
            this.btnOpenDown.Click += new System.EventHandler(this.btnOpenDown_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnG1DelAll);
            this.groupBox1.Controls.Add(this.btnG1DelOne);
            this.groupBox1.Controls.Add(this.radioButton7);
            this.groupBox1.Controls.Add(this.radioButton6);
            this.groupBox1.Controls.Add(this.radioButton5);
            this.groupBox1.Controls.Add(this.radioButton4);
            this.groupBox1.Location = new System.Drawing.Point(406, 313);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(377, 143);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "عمليات على القائمة الاولى";
            // 
            // btnG1DelAll
            // 
            this.btnG1DelAll.Location = new System.Drawing.Point(19, 101);
            this.btnG1DelAll.Name = "btnG1DelAll";
            this.btnG1DelAll.Size = new System.Drawing.Size(157, 27);
            this.btnG1DelAll.TabIndex = 13;
            this.btnG1DelAll.Text = "حذف الكل";
            this.btnG1DelAll.UseVisualStyleBackColor = true;
            this.btnG1DelAll.Click += new System.EventHandler(this.btnG1DelAll_Click);
            // 
            // btnG1DelOne
            // 
            this.btnG1DelOne.Location = new System.Drawing.Point(19, 25);
            this.btnG1DelOne.Name = "btnG1DelOne";
            this.btnG1DelOne.Size = new System.Drawing.Size(157, 27);
            this.btnG1DelOne.TabIndex = 12;
            this.btnG1DelOne.Text = "حذف عنصر مظلل";
            this.btnG1DelOne.UseVisualStyleBackColor = true;
            this.btnG1DelOne.Click += new System.EventHandler(this.btnG1DelOne_Click);
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(218, 107);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButton7.Size = new System.Drawing.Size(147, 21);
            this.radioButton7.TabIndex = 11;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "نقل العناصر معكوسة";
            this.radioButton7.UseVisualStyleBackColor = true;
            this.radioButton7.CheckedChanged += new System.EventHandler(this.radioButton7_CheckedChanged);
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(259, 81);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButton6.Size = new System.Drawing.Size(106, 21);
            this.radioButton6.TabIndex = 10;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "عكس العناصر";
            this.radioButton6.UseVisualStyleBackColor = true;
            this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton6_CheckedChanged);
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(212, 55);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButton5.Size = new System.Drawing.Size(153, 21);
            this.radioButton5.TabIndex = 9;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "ترتيب العناصر المظللة";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(193, 29);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButton4.Size = new System.Drawing.Size(172, 21);
            this.radioButton4.TabIndex = 8;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "ترتيب العناصر كامل تنازليا";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnG2DelAll);
            this.groupBox2.Controls.Add(this.btnG2DelOne);
            this.groupBox2.Controls.Add(this.radioButton9);
            this.groupBox2.Controls.Add(this.radioButton8);
            this.groupBox2.Location = new System.Drawing.Point(17, 313);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox2.Size = new System.Drawing.Size(372, 143);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "عمليات على القائمة الثانية";
            // 
            // btnG2DelAll
            // 
            this.btnG2DelAll.Location = new System.Drawing.Point(20, 101);
            this.btnG2DelAll.Name = "btnG2DelAll";
            this.btnG2DelAll.Size = new System.Drawing.Size(157, 27);
            this.btnG2DelAll.TabIndex = 15;
            this.btnG2DelAll.Text = "حذف الكل";
            this.btnG2DelAll.UseVisualStyleBackColor = true;
            this.btnG2DelAll.Click += new System.EventHandler(this.btnG2DelAll_Click);
            // 
            // btnG2DelOne
            // 
            this.btnG2DelOne.Location = new System.Drawing.Point(20, 25);
            this.btnG2DelOne.Name = "btnG2DelOne";
            this.btnG2DelOne.Size = new System.Drawing.Size(157, 27);
            this.btnG2DelOne.TabIndex = 14;
            this.btnG2DelOne.Text = "حذف عنصر مظلل";
            this.btnG2DelOne.UseVisualStyleBackColor = true;
            this.btnG2DelOne.Click += new System.EventHandler(this.btnG2DelOne_Click);
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(247, 90);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButton9.Size = new System.Drawing.Size(106, 21);
            this.radioButton9.TabIndex = 12;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "عكس العناصر";
            this.radioButton9.UseVisualStyleBackColor = true;
            this.radioButton9.CheckedChanged += new System.EventHandler(this.radioButton9_CheckedChanged);
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(213, 45);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButton8.Size = new System.Drawing.Size(140, 21);
            this.radioButton8.TabIndex = 11;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "ترتيب العناصر تنازليا";
            this.radioButton8.UseVisualStyleBackColor = true;
            this.radioButton8.CheckedChanged += new System.EventHandler(this.radioButton8_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnUnSelectedItemsCount);
            this.groupBox3.Controls.Add(this.txtUnSelectedItemsCount);
            this.groupBox3.Controls.Add(this.btnSelectedItemsCount);
            this.groupBox3.Controls.Add(this.txtSelectedItemsCount);
            this.groupBox3.Controls.Add(this.btnItemsCount);
            this.groupBox3.Controls.Add(this.txtItemsCount);
            this.groupBox3.Controls.Add(this.rdUnSelectAll);
            this.groupBox3.Controls.Add(this.rdSelectAll);
            this.groupBox3.Controls.Add(this.btnUnSelectIndex);
            this.groupBox3.Controls.Add(this.btnUnSelectItem);
            this.groupBox3.Controls.Add(this.btnSelectItem);
            this.groupBox3.Controls.Add(this.txtUnSelectIndex);
            this.groupBox3.Controls.Add(this.txtUnSelectItem);
            this.groupBox3.Controls.Add(this.txtSelectItem);
            this.groupBox3.Location = new System.Drawing.Point(17, 474);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox3.Size = new System.Drawing.Size(766, 310);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "عمليات اضافية على القائمة الاولى";
            // 
            // btnUnSelectedItemsCount
            // 
            this.btnUnSelectedItemsCount.Location = new System.Drawing.Point(389, 268);
            this.btnUnSelectedItemsCount.Name = "btnUnSelectedItemsCount";
            this.btnUnSelectedItemsCount.Size = new System.Drawing.Size(357, 27);
            this.btnUnSelectedItemsCount.TabIndex = 24;
            this.btnUnSelectedItemsCount.Text = "عدد العناصر الغير مظللة";
            this.btnUnSelectedItemsCount.UseVisualStyleBackColor = true;
            this.btnUnSelectedItemsCount.Click += new System.EventHandler(this.btnUnSelectedItemsCount_Click);
            // 
            // txtUnSelectedItemsCount
            // 
            this.txtUnSelectedItemsCount.Location = new System.Drawing.Point(20, 268);
            this.txtUnSelectedItemsCount.Name = "txtUnSelectedItemsCount";
            this.txtUnSelectedItemsCount.ReadOnly = true;
            this.txtUnSelectedItemsCount.Size = new System.Drawing.Size(352, 24);
            this.txtUnSelectedItemsCount.TabIndex = 23;
            // 
            // btnSelectedItemsCount
            // 
            this.btnSelectedItemsCount.Location = new System.Drawing.Point(389, 232);
            this.btnSelectedItemsCount.Name = "btnSelectedItemsCount";
            this.btnSelectedItemsCount.Size = new System.Drawing.Size(357, 27);
            this.btnSelectedItemsCount.TabIndex = 22;
            this.btnSelectedItemsCount.Text = "عدد العناصر المظللة";
            this.btnSelectedItemsCount.UseVisualStyleBackColor = true;
            this.btnSelectedItemsCount.Click += new System.EventHandler(this.btnSelectedItemsCount_Click);
            // 
            // txtSelectedItemsCount
            // 
            this.txtSelectedItemsCount.Location = new System.Drawing.Point(20, 232);
            this.txtSelectedItemsCount.Name = "txtSelectedItemsCount";
            this.txtSelectedItemsCount.ReadOnly = true;
            this.txtSelectedItemsCount.Size = new System.Drawing.Size(352, 24);
            this.txtSelectedItemsCount.TabIndex = 21;
            // 
            // btnItemsCount
            // 
            this.btnItemsCount.Location = new System.Drawing.Point(389, 196);
            this.btnItemsCount.Name = "btnItemsCount";
            this.btnItemsCount.Size = new System.Drawing.Size(357, 27);
            this.btnItemsCount.TabIndex = 20;
            this.btnItemsCount.Text = "عدد العناصر";
            this.btnItemsCount.UseVisualStyleBackColor = true;
            this.btnItemsCount.Click += new System.EventHandler(this.btnItemsCount_Click);
            // 
            // txtItemsCount
            // 
            this.txtItemsCount.Location = new System.Drawing.Point(20, 196);
            this.txtItemsCount.Name = "txtItemsCount";
            this.txtItemsCount.ReadOnly = true;
            this.txtItemsCount.Size = new System.Drawing.Size(352, 24);
            this.txtItemsCount.TabIndex = 19;
            // 
            // rdUnSelectAll
            // 
            this.rdUnSelectAll.AutoSize = true;
            this.rdUnSelectAll.Location = new System.Drawing.Point(164, 159);
            this.rdUnSelectAll.Name = "rdUnSelectAll";
            this.rdUnSelectAll.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.rdUnSelectAll.Size = new System.Drawing.Size(208, 21);
            this.rdUnSelectAll.TabIndex = 18;
            this.rdUnSelectAll.TabStop = true;
            this.rdUnSelectAll.Text = "ازالة التظليل على جميع العناصر";
            this.rdUnSelectAll.UseVisualStyleBackColor = true;
            this.rdUnSelectAll.CheckedChanged += new System.EventHandler(this.rdUnSelectAll_CheckedChanged);
            // 
            // rdSelectAll
            // 
            this.rdSelectAll.AutoSize = true;
            this.rdSelectAll.Location = new System.Drawing.Point(565, 159);
            this.rdSelectAll.Name = "rdSelectAll";
            this.rdSelectAll.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.rdSelectAll.Size = new System.Drawing.Size(181, 21);
            this.rdSelectAll.TabIndex = 17;
            this.rdSelectAll.TabStop = true;
            this.rdSelectAll.Text = "التظليل على جميع العناصر";
            this.rdSelectAll.UseVisualStyleBackColor = true;
            this.rdSelectAll.CheckedChanged += new System.EventHandler(this.rdSelectAll_CheckedChanged);
            // 
            // btnUnSelectIndex
            // 
            this.btnUnSelectIndex.Location = new System.Drawing.Point(389, 118);
            this.btnUnSelectIndex.Name = "btnUnSelectIndex";
            this.btnUnSelectIndex.Size = new System.Drawing.Size(357, 27);
            this.btnUnSelectIndex.TabIndex = 16;
            this.btnUnSelectIndex.Text = "ازالة التظليل على العنصر بالاندكس";
            this.btnUnSelectIndex.UseVisualStyleBackColor = true;
            this.btnUnSelectIndex.Click += new System.EventHandler(this.btnUnSelectIndex_Click);
            // 
            // btnUnSelectItem
            // 
            this.btnUnSelectItem.Location = new System.Drawing.Point(389, 77);
            this.btnUnSelectItem.Name = "btnUnSelectItem";
            this.btnUnSelectItem.Size = new System.Drawing.Size(357, 27);
            this.btnUnSelectItem.TabIndex = 15;
            this.btnUnSelectItem.Text = "ازالة التظليل على العنصر";
            this.btnUnSelectItem.UseVisualStyleBackColor = true;
            this.btnUnSelectItem.Click += new System.EventHandler(this.btnUnSelectItem_Click);
            // 
            // btnSelectItem
            // 
            this.btnSelectItem.Location = new System.Drawing.Point(389, 37);
            this.btnSelectItem.Name = "btnSelectItem";
            this.btnSelectItem.Size = new System.Drawing.Size(357, 27);
            this.btnSelectItem.TabIndex = 14;
            this.btnSelectItem.Text = "عمل تظليل على العنصر";
            this.btnSelectItem.UseVisualStyleBackColor = true;
            this.btnSelectItem.Click += new System.EventHandler(this.btnSelectItem_Click);
            // 
            // txtUnSelectIndex
            // 
            this.txtUnSelectIndex.Location = new System.Drawing.Point(20, 118);
            this.txtUnSelectIndex.Name = "txtUnSelectIndex";
            this.txtUnSelectIndex.Size = new System.Drawing.Size(352, 24);
            this.txtUnSelectIndex.TabIndex = 3;
            this.txtUnSelectIndex.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdd_KeyPress);
            // 
            // txtUnSelectItem
            // 
            this.txtUnSelectItem.Location = new System.Drawing.Point(20, 77);
            this.txtUnSelectItem.Name = "txtUnSelectItem";
            this.txtUnSelectItem.Size = new System.Drawing.Size(352, 24);
            this.txtUnSelectItem.TabIndex = 2;
            this.txtUnSelectItem.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdd_KeyPress);
            // 
            // txtSelectItem
            // 
            this.txtSelectItem.Location = new System.Drawing.Point(20, 37);
            this.txtSelectItem.Name = "txtSelectItem";
            this.txtSelectItem.Size = new System.Drawing.Size(352, 24);
            this.txtSelectItem.TabIndex = 1;
            this.txtSelectItem.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdd_KeyPress);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(17, 794);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 24);
            this.btnClose.TabIndex = 10;
            this.btnClose.Text = "اغـــلاق";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 825);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnOpenDown);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.txtAdd);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtAdd;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rdPrime;
        private System.Windows.Forms.RadioButton rdOdd;
        private System.Windows.Forms.RadioButton rdEven;
        private System.Windows.Forms.Button btnMOne;
        private System.Windows.Forms.Button btnMAll;
        private System.Windows.Forms.Button btnOpenDown;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnG1DelAll;
        private System.Windows.Forms.Button btnG1DelOne;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnG2DelAll;
        private System.Windows.Forms.Button btnG2DelOne;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnSelectItem;
        private System.Windows.Forms.TextBox txtUnSelectItem;
        private System.Windows.Forms.TextBox txtSelectItem;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSelectedItemsCount;
        private System.Windows.Forms.TextBox txtSelectedItemsCount;
        private System.Windows.Forms.Button btnItemsCount;
        private System.Windows.Forms.TextBox txtItemsCount;
        private System.Windows.Forms.RadioButton rdUnSelectAll;
        private System.Windows.Forms.RadioButton rdSelectAll;
        private System.Windows.Forms.Button btnUnSelectItem;
        private System.Windows.Forms.Button btnUnSelectedItemsCount;
        private System.Windows.Forms.TextBox txtUnSelectedItemsCount;
        private System.Windows.Forms.Button btnUnSelectIndex;
        private System.Windows.Forms.TextBox txtUnSelectIndex;
        private System.Windows.Forms.Button btnMAllRevers;
    }
}

