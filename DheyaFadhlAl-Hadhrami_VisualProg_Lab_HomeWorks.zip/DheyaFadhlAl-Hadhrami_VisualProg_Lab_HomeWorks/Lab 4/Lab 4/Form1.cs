﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_4
{
    public partial class Form1 : Form
    {
        int[] n;
        int m = 0, i = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtAvg.Enabled = txtName.Enabled = btnAdd.Enabled = btnSort.Enabled = listBox1.Enabled = false;
            txtNum.KeyPress += txtName_KeyPress;
            txtAvg.KeyPress += txtName_KeyPress;
        }

        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (sender == txtAvg || sender == txtNum)
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }

            if (sender == txtName)
            {
                if ((e.KeyChar >= 65 && e.KeyChar <= 90) ||
                    (e.KeyChar >= 97 && e.KeyChar <= 122) ||
                    (e.KeyChar >= 'ء' && e.KeyChar <= 'ي') ||
                    e.KeyChar == 8 || e.KeyChar == 32)
                {
                    e.Handled = false;
                }
                else
                {
                    e.Handled = true;
                }
            }
        }

        private void txtNum_TextChanged(object sender, EventArgs e)
        {
            txtAvg.Enabled = txtName.Enabled = btnAdd.Enabled = btnSort.Enabled 
                = listBox1.Enabled = (txtNum.Text.Trim() != "");

        }

        private void txtNum_Leave(object sender, EventArgs e)
        {
            if (txtNum.Text.Trim() != "")
            {
                m = Convert.ToInt32(txtNum.Text.Trim());
                n = new int[m];
                i = 0;
            }
            listBox1.Items.Clear();
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            int b = listBox1.Items.Count, temp = n[0]; string s = "";
            if (b > 0)
            {
                for (int k = 0; k < i; k++)
                {
                    for (int j = k+1; j < i; j++)
                    {
                        if (n[k] > n[j])
                        {
                            temp = n[k];
                            n[k] = n[j];
                            n[k] = temp;
                            s = listBox1.Items[k].ToString();
                            listBox1.Items[k] = listBox1.Items[j].ToString();
                            listBox1.Items[j] = s;
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("القائمة فارغة");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtAvg.Text.Trim() != "" && txtName.Text.Trim() != "")
            {
                if (i < m)
                {
                    listBox1.Items.Add(txtName.Text + "\t" + txtAvg.Text);
                    n[i++] = int.Parse(txtAvg.Text);
                    txtAvg.Text = txtName.Text = "";
                    txtAvg.Focus();
                    txtName.Focus();
                }
                else
                {
                    MessageBox.Show("لقد تجاوزت حد المصفوفة");
                    txtName.Clear();
                    txtAvg.Clear();
                    return;
                }
            }
            else
            {
                MessageBox.Show("خطا في مربع النص");
            }
        }
    }
}
