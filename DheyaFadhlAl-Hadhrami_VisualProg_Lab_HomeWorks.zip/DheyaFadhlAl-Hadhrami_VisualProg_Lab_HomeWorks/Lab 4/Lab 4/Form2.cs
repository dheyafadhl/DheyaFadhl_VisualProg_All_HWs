﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_4
{
    public partial class Form2 : Form
    {
        bool s = false;
        bool p = false;
        public Form2()
        {
            InitializeComponent();
        }
        Thread threadgo;
        Thread thread2go;
        private void btnMRight_Click(object sender, EventArgs e)
        {
            threadgo = new Thread(go);
            threadgo.Start();
            s = true;
        }
        void go()
        {
            bool test = false;
            while (true)
            {
                //int start = btnRight.Left;
                //MessageBox.Show(start.ToString());
                for (int i = 0; i <= this.Width; i++)
                {
                    Invoke((Action)(() => { btnRight.Left += 10; }));

                    if (btnRight.Left > this.Width - btnRight.Width - 20)
                    {
                        break;
                    }

                    System.Threading.Thread.Sleep(50);
                }

                for (int i = 0; i < this.Width; i++)
                {
                    Invoke((Action)(() => { btnRight.Left -= 10; }));
                    if (btnRight.Left == btnDown.Left)
                    {
                        break;
                    }
                    System.Threading.Thread.Sleep(50);
                }
            }
        }
        void go2()
        {
            //MessageBox.Show(btnRight.Bottom.ToString());
            while (true)
            {
                //int start = btnRight.Left;
                //MessageBox.Show(start.ToString());
                for (int i = 0; i <= this.Height - btnDown.Height; i++)
                {
                    Invoke((Action)(() => { btnDown.Top += 10; }));

                    if (btnDown.Top > this.Height - btnDown.Height - 20)
                    {
                        break;
                    }

                    System.Threading.Thread.Sleep(50);
                }

                for (int i = 0; i < this.Height; i++)
                {
                    Invoke((Action)(() => { btnDown.Top -= 10; }));
                    if (btnDown.Top == btnRight.Bottom + 5)
                    {
                        break;
                    }
                    System.Threading.Thread.Sleep(50);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (s)
            {
                threadgo.Abort();
            }
            else
            {
                MessageBox.Show("Button Is Static..", "Exception");
            }
        }

        private void btnMDown_Click(object sender, EventArgs e)
        {
            thread2go = new Thread(go2);
            thread2go.Start();
            p = true;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (p)
            {
                thread2go.Abort();
            }
            else
            {
                MessageBox.Show("Button Is Static..", "Exception");
            }
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (threadgo != null)
            {
                threadgo.Abort();
            }
            if (thread2go != null)
            {
                thread2go.Abort();
            }
        }

    }
}
