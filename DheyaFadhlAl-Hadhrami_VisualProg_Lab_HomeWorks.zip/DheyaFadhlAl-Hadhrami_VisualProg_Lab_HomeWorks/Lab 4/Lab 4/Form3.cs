﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_4
{
    public partial class Form3 : Form
    {

        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel1.Location = new Point(button1.Left, button1.Height + 20);

            textBox1.Text = textBox2.Text = textBox3.Text = "";

            this.Width = button4.Left + button4.Width + 25;
            this.Height = button1.Height + 60;

            button2.Click += button1_Click;
            button3.Click += button1_Click;
            button4.Click += button1_Click;

            textBox3.ReadOnly = true;

            textBox2.KeyPress += textBox1_KeyPress;

            this.CenterToParent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            this.Height = button1.Height + 60;
            this.Height += panel1.Height + 10;

            textBox3.Clear();

            panel1.Visible = true;


            if (sender == button1)
            {
                label4.Text = "+";
                panel1.BackColor = Color.HotPink;

            }

            if (sender == button2)
            {
                label4.Text = "-";
                panel1.BackColor = Color.Cyan;
            }

            if (sender == button3)
            {
                label4.Text = "*";
                panel1.BackColor = Color.LightSeaGreen;
            }

            if (sender == button4)
            {
                label4.Text = "/";
                panel1.BackColor = Color.LightYellow;
            }
            
            if (textBox1.Text != "" || textBox2.Text != "")
            {
                button6_Click(sender, null);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form3_Load(null, null);
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (label4.Text == "+")
            {
                textBox3.Text = (Convert.ToDouble(textBox1.Text) + Convert.ToDouble(textBox2.Text)).ToString();
            }

            if (label4.Text == "-")
            {
                textBox3.Text = (Convert.ToDouble(textBox1.Text) - Convert.ToDouble(textBox2.Text)).ToString();
            }

            if (label4.Text == "*")
            {
                textBox3.Text = (Convert.ToDouble(textBox1.Text) * Convert.ToDouble(textBox2.Text)).ToString();
            }

            if (label4.Text == "/")
            {
                if (Convert.ToDouble(textBox2.Text) == 0)
                {
                    MessageBox.Show("Can Not Div By 0.", "Error");
                    textBox2.Clear();
                    textBox2.Focus();
                }
                else
                {
                    textBox3.Text = (Convert.ToDouble(textBox1.Text) / Convert.ToDouble(textBox2.Text)).ToString();
                }
            }
        }
    }
}
