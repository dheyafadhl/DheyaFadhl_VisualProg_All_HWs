﻿namespace Lab_4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnMDown = new System.Windows.Forms.Button();
            this.btnMRight = new System.Windows.Forms.Button();
            this.btnDown = new System.Windows.Forms.Button();
            this.btnRight = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(413, 387);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(184, 43);
            this.button1.TabIndex = 11;
            this.button1.Text = "StopDown";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(190, 387);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(184, 43);
            this.button2.TabIndex = 10;
            this.button2.Text = "StopRight";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnMDown
            // 
            this.btnMDown.Location = new System.Drawing.Point(413, 331);
            this.btnMDown.Name = "btnMDown";
            this.btnMDown.Size = new System.Drawing.Size(184, 43);
            this.btnMDown.TabIndex = 9;
            this.btnMDown.Text = "Move TO Down";
            this.btnMDown.UseVisualStyleBackColor = true;
            this.btnMDown.Click += new System.EventHandler(this.btnMDown_Click);
            // 
            // btnMRight
            // 
            this.btnMRight.Location = new System.Drawing.Point(190, 331);
            this.btnMRight.Name = "btnMRight";
            this.btnMRight.Size = new System.Drawing.Size(184, 43);
            this.btnMRight.TabIndex = 8;
            this.btnMRight.Text = "Move TO Right";
            this.btnMRight.UseVisualStyleBackColor = true;
            this.btnMRight.Click += new System.EventHandler(this.btnMRight_Click);
            // 
            // btnDown
            // 
            this.btnDown.Location = new System.Drawing.Point(4, 43);
            this.btnDown.Name = "btnDown";
            this.btnDown.Size = new System.Drawing.Size(118, 33);
            this.btnDown.TabIndex = 7;
            this.btnDown.Text = "v";
            this.btnDown.UseVisualStyleBackColor = true;
            // 
            // btnRight
            // 
            this.btnRight.Location = new System.Drawing.Point(4, 4);
            this.btnRight.Name = "btnRight";
            this.btnRight.Size = new System.Drawing.Size(118, 33);
            this.btnRight.TabIndex = 6;
            this.btnRight.Text = ">";
            this.btnRight.UseVisualStyleBackColor = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(607, 440);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnMDown);
            this.Controls.Add(this.btnMRight);
            this.Controls.Add(this.btnDown);
            this.Controls.Add(this.btnRight);
            this.Name = "Form2";
            this.Text = "Form2";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnMDown;
        private System.Windows.Forms.Button btnMRight;
        private System.Windows.Forms.Button btnDown;
        private System.Windows.Forms.Button btnRight;
    }
}