﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int Sum = 0;
            bool test = false;
            if (checkBox1.Checked)
            {
                Sum += 100;
                test = true;
            }
            if (checkBox2.Checked)
            {
                Sum += 200;
                test = true;
            }
            if (checkBox3.Checked)
            {
                Sum += 300;
                test = true;
            }
            if (checkBox4.Checked)
            {
                Sum += 400;
                test = true;
            }
            if (checkBox5.Checked)
            {
                Sum += 500;
                test = true;
            }
            if (!test)
            {
                MessageBox.Show("Please Select Numbers To Sum");
            }
            textBox1.Text = Sum.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool test = false;
            if(radioButton5.Checked)
            {
                label4.ForeColor = Color.Red;
                test = true;
            }
            if (radioButton6.Checked)
            {
                label4.ForeColor = Color.Blue;
                test = true;
            }
            if (radioButton7.Checked)
            {
                label4.ForeColor= Color.Green;
                test = true;
            }
            if (radioButton8.Checked)
            {
                label4.ForeColor = Color.Yellow;
                test = true;
            }
            if (radioButton1.Checked)
            {
                label4.BackColor = Color.Red;
                test = true;
            }
            if (radioButton2.Checked)
            {
                label4.BackColor = Color.Blue;
                test = true;
            }
            if (radioButton3.Checked)
            {
                label4.BackColor = Color.Green;
                test = true;
            }
            if (radioButton4.Checked)
            {
                label4.BackColor = Color.Yellow;
                test = true;
            }
            if (!test)
            {
                MessageBox.Show("Select Color Please");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (button6.Text == "Visible")
            {
                panel1.Visible = true;
                button6.Text = "UnVisible";
            }
            else
            {
                panel1.Visible = false;
                button6.Text = "Visible";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button3.Text == "Enable")
            {
                panel1.Enabled = true;
                button3.Text = "Disable";
            }
            else
            {
                panel1.Enabled = false;
                button3.Text = "Enable";
            }
        }
    }
}