﻿namespace Lab_8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAllLength = new System.Windows.Forms.Button();
            this.btnSelectedLength = new System.Windows.Forms.Button();
            this.btnWordsCount = new System.Windows.Forms.Button();
            this.btnDelSelected = new System.Windows.Forms.Button();
            this.btnUnSelect = new System.Windows.Forms.Button();
            this.btnCopy = new System.Windows.Forms.Button();
            this.btnMove = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtAllLength = new System.Windows.Forms.TextBox();
            this.txtSelectedLength = new System.Windows.Forms.TextBox();
            this.txtWordsCount = new System.Windows.Forms.TextBox();
            this.btnAllCharLength = new System.Windows.Forms.Button();
            this.btnAllSelectedCharLength = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnSearchPrevious = new System.Windows.Forms.Button();
            this.btnSearchNext = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSearchText = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnReplace = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNewText = new System.Windows.Forms.TextBox();
            this.txtPasteBox = new System.Windows.Forms.TextBox();
            this.btnPaste = new System.Windows.Forms.Button();
            this.btnUndo = new System.Windows.Forms.Button();
            this.btnShowSelectedWordChars = new System.Windows.Forms.Button();
            this.btnShowSelectedTextWords = new System.Windows.Forms.Button();
            this.listBoxChar = new System.Windows.Forms.ListBox();
            this.listBoxWords = new System.Windows.Forms.ListBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnSearchPattren = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSearchPattren = new System.Windows.Forms.TextBox();
            this.txtAllText = new System.Windows.Forms.RichTextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAllLength
            // 
            this.btnAllLength.Location = new System.Drawing.Point(986, 95);
            this.btnAllLength.Name = "btnAllLength";
            this.btnAllLength.Size = new System.Drawing.Size(153, 34);
            this.btnAllLength.TabIndex = 1;
            this.btnAllLength.Text = "طول النص كامل";
            this.btnAllLength.UseVisualStyleBackColor = true;
            this.btnAllLength.Click += new System.EventHandler(this.btnAllLength_Click);
            // 
            // btnSelectedLength
            // 
            this.btnSelectedLength.Location = new System.Drawing.Point(822, 95);
            this.btnSelectedLength.Name = "btnSelectedLength";
            this.btnSelectedLength.Size = new System.Drawing.Size(158, 34);
            this.btnSelectedLength.TabIndex = 2;
            this.btnSelectedLength.Text = "طول النص المحدد";
            this.btnSelectedLength.UseVisualStyleBackColor = true;
            this.btnSelectedLength.Click += new System.EventHandler(this.btnSelectedLength_Click);
            // 
            // btnWordsCount
            // 
            this.btnWordsCount.Location = new System.Drawing.Point(661, 95);
            this.btnWordsCount.Name = "btnWordsCount";
            this.btnWordsCount.Size = new System.Drawing.Size(155, 34);
            this.btnWordsCount.TabIndex = 3;
            this.btnWordsCount.Text = "عدد الكلمات";
            this.btnWordsCount.UseVisualStyleBackColor = true;
            this.btnWordsCount.Click += new System.EventHandler(this.btnWordsCount_Click);
            // 
            // btnDelSelected
            // 
            this.btnDelSelected.Location = new System.Drawing.Point(500, 95);
            this.btnDelSelected.Name = "btnDelSelected";
            this.btnDelSelected.Size = new System.Drawing.Size(155, 34);
            this.btnDelSelected.TabIndex = 4;
            this.btnDelSelected.Text = "حذف النص المحدد";
            this.btnDelSelected.UseVisualStyleBackColor = true;
            this.btnDelSelected.Click += new System.EventHandler(this.btnDelSelected_Click);
            // 
            // btnUnSelect
            // 
            this.btnUnSelect.Location = new System.Drawing.Point(339, 95);
            this.btnUnSelect.Name = "btnUnSelect";
            this.btnUnSelect.Size = new System.Drawing.Size(155, 34);
            this.btnUnSelect.TabIndex = 5;
            this.btnUnSelect.Text = "الغاء التحديد";
            this.btnUnSelect.UseVisualStyleBackColor = true;
            this.btnUnSelect.Click += new System.EventHandler(this.btnUnSelect_Click);
            // 
            // btnCopy
            // 
            this.btnCopy.Location = new System.Drawing.Point(228, 95);
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(105, 34);
            this.btnCopy.TabIndex = 6;
            this.btnCopy.Text = "نسخ";
            this.btnCopy.UseVisualStyleBackColor = true;
            this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
            // 
            // btnMove
            // 
            this.btnMove.Location = new System.Drawing.Point(117, 95);
            this.btnMove.Name = "btnMove";
            this.btnMove.Size = new System.Drawing.Size(105, 34);
            this.btnMove.TabIndex = 7;
            this.btnMove.Text = "قـــص";
            this.btnMove.UseVisualStyleBackColor = true;
            this.btnMove.Click += new System.EventHandler(this.btnMove_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(12, 95);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(99, 34);
            this.btnClear.TabIndex = 8;
            this.btnClear.Text = "تنظيـــــف";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtAllLength
            // 
            this.txtAllLength.Location = new System.Drawing.Point(986, 137);
            this.txtAllLength.Name = "txtAllLength";
            this.txtAllLength.Size = new System.Drawing.Size(153, 24);
            this.txtAllLength.TabIndex = 9;
            // 
            // txtSelectedLength
            // 
            this.txtSelectedLength.Location = new System.Drawing.Point(822, 137);
            this.txtSelectedLength.Name = "txtSelectedLength";
            this.txtSelectedLength.Size = new System.Drawing.Size(158, 24);
            this.txtSelectedLength.TabIndex = 10;
            // 
            // txtWordsCount
            // 
            this.txtWordsCount.Location = new System.Drawing.Point(661, 137);
            this.txtWordsCount.Name = "txtWordsCount";
            this.txtWordsCount.Size = new System.Drawing.Size(155, 24);
            this.txtWordsCount.TabIndex = 11;
            // 
            // btnAllCharLength
            // 
            this.btnAllCharLength.Location = new System.Drawing.Point(339, 135);
            this.btnAllCharLength.Name = "btnAllCharLength";
            this.btnAllCharLength.Size = new System.Drawing.Size(316, 29);
            this.btnAllCharLength.TabIndex = 12;
            this.btnAllCharLength.Text = "طول النص كامل بدون الفراغات";
            this.btnAllCharLength.UseVisualStyleBackColor = true;
            this.btnAllCharLength.Click += new System.EventHandler(this.btnAllCharLength_Click);
            // 
            // btnAllSelectedCharLength
            // 
            this.btnAllSelectedCharLength.Location = new System.Drawing.Point(12, 135);
            this.btnAllSelectedCharLength.Name = "btnAllSelectedCharLength";
            this.btnAllSelectedCharLength.Size = new System.Drawing.Size(321, 29);
            this.btnAllSelectedCharLength.TabIndex = 13;
            this.btnAllSelectedCharLength.Text = "طول النص المحدد بدون الفراغات";
            this.btnAllSelectedCharLength.UseVisualStyleBackColor = true;
            this.btnAllSelectedCharLength.Click += new System.EventHandler(this.btnAllSelectedCharLength_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnSearchPrevious);
            this.groupBox1.Controls.Add(this.btnSearchNext);
            this.groupBox1.Controls.Add(this.btnSearch);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtSearchText);
            this.groupBox1.Location = new System.Drawing.Point(12, 175);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(553, 100);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "بحـــث";
            // 
            // btnSearchPrevious
            // 
            this.btnSearchPrevious.Location = new System.Drawing.Point(6, 59);
            this.btnSearchPrevious.Name = "btnSearchPrevious";
            this.btnSearchPrevious.Size = new System.Drawing.Size(174, 29);
            this.btnSearchPrevious.TabIndex = 4;
            this.btnSearchPrevious.Text = "بحث عن السابق";
            this.btnSearchPrevious.UseVisualStyleBackColor = true;
            this.btnSearchPrevious.Click += new System.EventHandler(this.btnSearchPrevious_Click);
            // 
            // btnSearchNext
            // 
            this.btnSearchNext.Location = new System.Drawing.Point(189, 59);
            this.btnSearchNext.Name = "btnSearchNext";
            this.btnSearchNext.Size = new System.Drawing.Size(174, 29);
            this.btnSearchNext.TabIndex = 3;
            this.btnSearchNext.Text = "بحث عن التالي";
            this.btnSearchNext.UseVisualStyleBackColor = true;
            this.btnSearchNext.Click += new System.EventHandler(this.btnSearchNext_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(372, 59);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(174, 29);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "بحث";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(411, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "النص المراد البحث عنه";
            // 
            // txtSearchText
            // 
            this.txtSearchText.Location = new System.Drawing.Point(6, 23);
            this.txtSearchText.Name = "txtSearchText";
            this.txtSearchText.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtSearchText.Size = new System.Drawing.Size(399, 24);
            this.txtSearchText.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnReplace);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtNewText);
            this.groupBox2.Location = new System.Drawing.Point(586, 175);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox2.Size = new System.Drawing.Size(553, 100);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "استبدال";
            // 
            // btnReplace
            // 
            this.btnReplace.Location = new System.Drawing.Point(189, 59);
            this.btnReplace.Name = "btnReplace";
            this.btnReplace.Size = new System.Drawing.Size(174, 29);
            this.btnReplace.TabIndex = 7;
            this.btnReplace.Text = "استبدال";
            this.btnReplace.UseVisualStyleBackColor = true;
            this.btnReplace.Click += new System.EventHandler(this.btnReplace_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(450, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "النص الجديـــــد";
            // 
            // txtNewText
            // 
            this.txtNewText.Location = new System.Drawing.Point(6, 26);
            this.txtNewText.Name = "txtNewText";
            this.txtNewText.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtNewText.Size = new System.Drawing.Size(438, 24);
            this.txtNewText.TabIndex = 1;
            // 
            // txtPasteBox
            // 
            this.txtPasteBox.Location = new System.Drawing.Point(586, 325);
            this.txtPasteBox.Multiline = true;
            this.txtPasteBox.Name = "txtPasteBox";
            this.txtPasteBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtPasteBox.Size = new System.Drawing.Size(553, 293);
            this.txtPasteBox.TabIndex = 16;
            // 
            // btnPaste
            // 
            this.btnPaste.Location = new System.Drawing.Point(965, 286);
            this.btnPaste.Name = "btnPaste";
            this.btnPaste.Size = new System.Drawing.Size(174, 29);
            this.btnPaste.TabIndex = 17;
            this.btnPaste.Text = "لصق";
            this.btnPaste.UseVisualStyleBackColor = true;
            this.btnPaste.Click += new System.EventHandler(this.btnPaste_Click);
            // 
            // btnUndo
            // 
            this.btnUndo.Location = new System.Drawing.Point(586, 286);
            this.btnUndo.Name = "btnUndo";
            this.btnUndo.Size = new System.Drawing.Size(174, 29);
            this.btnUndo.TabIndex = 18;
            this.btnUndo.Text = "تراجع";
            this.btnUndo.UseVisualStyleBackColor = true;
            this.btnUndo.Click += new System.EventHandler(this.btnUndo_Click);
            // 
            // btnShowSelectedWordChars
            // 
            this.btnShowSelectedWordChars.Location = new System.Drawing.Point(369, 415);
            this.btnShowSelectedWordChars.Name = "btnShowSelectedWordChars";
            this.btnShowSelectedWordChars.Size = new System.Drawing.Size(196, 29);
            this.btnShowSelectedWordChars.TabIndex = 20;
            this.btnShowSelectedWordChars.Text = "عرض احرف الكلمة المحددة";
            this.btnShowSelectedWordChars.UseVisualStyleBackColor = true;
            this.btnShowSelectedWordChars.Click += new System.EventHandler(this.btnShowSelectedWordChars_Click);
            // 
            // btnShowSelectedTextWords
            // 
            this.btnShowSelectedTextWords.Location = new System.Drawing.Point(12, 415);
            this.btnShowSelectedTextWords.Name = "btnShowSelectedTextWords";
            this.btnShowSelectedTextWords.Size = new System.Drawing.Size(351, 29);
            this.btnShowSelectedTextWords.TabIndex = 23;
            this.btnShowSelectedTextWords.Text = "عرض كلمات الجملة المحددة";
            this.btnShowSelectedTextWords.UseVisualStyleBackColor = true;
            this.btnShowSelectedTextWords.Click += new System.EventHandler(this.btnShowSelectedTextWords_Click);
            // 
            // listBoxChar
            // 
            this.listBoxChar.FormattingEnabled = true;
            this.listBoxChar.ItemHeight = 16;
            this.listBoxChar.Location = new System.Drawing.Point(369, 454);
            this.listBoxChar.Name = "listBoxChar";
            this.listBoxChar.Size = new System.Drawing.Size(196, 164);
            this.listBoxChar.TabIndex = 24;
            // 
            // listBoxWords
            // 
            this.listBoxWords.FormattingEnabled = true;
            this.listBoxWords.ItemHeight = 16;
            this.listBoxWords.Location = new System.Drawing.Point(12, 454);
            this.listBoxWords.Name = "listBoxWords";
            this.listBoxWords.Size = new System.Drawing.Size(351, 164);
            this.listBoxWords.TabIndex = 25;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnSearchPattren);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.txtSearchPattren);
            this.groupBox3.Location = new System.Drawing.Point(12, 286);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox3.Size = new System.Drawing.Size(553, 119);
            this.groupBox3.TabIndex = 26;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "بحث عن نمط معين";
            // 
            // btnSearchPattren
            // 
            this.btnSearchPattren.Location = new System.Drawing.Point(6, 71);
            this.btnSearchPattren.Name = "btnSearchPattren";
            this.btnSearchPattren.Size = new System.Drawing.Size(399, 29);
            this.btnSearchPattren.TabIndex = 6;
            this.btnSearchPattren.Text = "بحث";
            this.btnSearchPattren.UseVisualStyleBackColor = true;
            this.btnSearchPattren.Click += new System.EventHandler(this.btnSearchPattern_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(411, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "النمط المراد البحث عنه";
            // 
            // txtSearchPattren
            // 
            this.txtSearchPattren.Location = new System.Drawing.Point(6, 31);
            this.txtSearchPattren.Name = "txtSearchPattren";
            this.txtSearchPattren.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtSearchPattren.Size = new System.Drawing.Size(399, 24);
            this.txtSearchPattren.TabIndex = 2;
            // 
            // txtAllText
            // 
            this.txtAllText.Location = new System.Drawing.Point(12, 12);
            this.txtAllText.Name = "txtAllText";
            this.txtAllText.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtAllText.Size = new System.Drawing.Size(1127, 70);
            this.txtAllText.TabIndex = 27;
            this.txtAllText.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1151, 628);
            this.Controls.Add(this.txtAllText);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.listBoxWords);
            this.Controls.Add(this.listBoxChar);
            this.Controls.Add(this.txtPasteBox);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnAllSelectedCharLength);
            this.Controls.Add(this.btnAllCharLength);
            this.Controls.Add(this.txtWordsCount);
            this.Controls.Add(this.txtSelectedLength);
            this.Controls.Add(this.txtAllLength);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnMove);
            this.Controls.Add(this.btnCopy);
            this.Controls.Add(this.btnUnSelect);
            this.Controls.Add(this.btnDelSelected);
            this.Controls.Add(this.btnWordsCount);
            this.Controls.Add(this.btnSelectedLength);
            this.Controls.Add(this.btnAllLength);
            this.Controls.Add(this.btnShowSelectedTextWords);
            this.Controls.Add(this.btnShowSelectedWordChars);
            this.Controls.Add(this.btnUndo);
            this.Controls.Add(this.btnPaste);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnAllLength;
        private System.Windows.Forms.Button btnSelectedLength;
        private System.Windows.Forms.Button btnWordsCount;
        private System.Windows.Forms.Button btnDelSelected;
        private System.Windows.Forms.Button btnUnSelect;
        private System.Windows.Forms.Button btnCopy;
        private System.Windows.Forms.Button btnMove;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox txtAllLength;
        private System.Windows.Forms.TextBox txtSelectedLength;
        private System.Windows.Forms.TextBox txtWordsCount;
        private System.Windows.Forms.Button btnAllSelectedCharLength;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnSearchPrevious;
        private System.Windows.Forms.Button btnSearchNext;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSearchText;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnReplace;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNewText;
        private System.Windows.Forms.TextBox txtPasteBox;
        private System.Windows.Forms.Button btnPaste;
        private System.Windows.Forms.Button btnUndo;
        private System.Windows.Forms.Button btnShowSelectedWordChars;
        private System.Windows.Forms.Button btnShowSelectedTextWords;
        private System.Windows.Forms.Button btnAllCharLength;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ListBox listBoxChar;
        private System.Windows.Forms.ListBox listBoxWords;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnSearchPattren;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSearchPattren;
        private System.Windows.Forms.RichTextBox txtAllText;
    }
}

