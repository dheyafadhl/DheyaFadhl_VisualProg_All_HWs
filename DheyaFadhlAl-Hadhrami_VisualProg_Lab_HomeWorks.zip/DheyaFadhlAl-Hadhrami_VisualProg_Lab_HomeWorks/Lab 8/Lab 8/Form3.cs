﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_8
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            textBox2.ReadOnly = true;
            textBox3.ReadOnly = true;

            Random random = new Random();
            for (int i = 0; i < 10; i++)
            {
                listBox1.Items.Add(random.Next(0, 100).ToString());
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.IndexOf(textBox1.Text) == -1)
            {
                if (textBox1.Text != "")
                {
                    if (listBox1.Items.Count == 20)
                    {
                        MessageBox.Show("List OverFlow..", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        btnDelAll.Focus();
                    }
                    listBox1.Items.Add(textBox1.Text);
                    textBox1.Clear();
                    textBox1.Focus();
                }
                else
                {
                    MessageBox.Show("Insert Number To Add..", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBox1.Focus();
                }
            }
            else
            {
                textBox1.Clear();
                textBox1.Focus();
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            int n = listBox1.SelectedIndex;
            if (n != -1 || listBox1.Items.Count != 0) 
            {    
                try
                {
                    listBox1.Items.RemoveAt(n);

                    if(textBox2.Text != "")
                    {
                        btnSum_Click(sender, e);
                    }

                    if(textBox3.Text != "")
                    {
                        btnAvg_Click(sender, e);
                    }

                    if (n >= listBox1.Items.Count)
                    {
                        n = listBox1.Items.Count - 1;
                    }

                    if (n != -1)
                    {
                        listBox1.SelectedIndex = n;
                    }
                }
                catch (Exception ex)
                {               
                    MessageBox.Show($"Error: {ex.Message}", "Exception");
                }
            }
            else
            {
                MessageBox.Show("Select Element To Delete..", "Error");
            }                           
        }

        private void btnDelAll_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void btnSum_Click(object sender, EventArgs e)
        {
            int size = listBox1.Items.Count;
            if (size == 0)
            {
                //MessageBox.Show("No Items in List..", "Error");
                textBox2.Clear();
            }
            else
            {
                int sum = 0;
                for (int i = 0; i <  size; i++)
                {
                    sum += int.Parse(listBox1.Items[i].ToString());
                } 
                textBox2.Text = sum.ToString();
            }
        }

        private void btnAvg_Click(object sender, EventArgs e)
        {
            int size = listBox1.Items.Count;
            if (size == 0)
            {
                //MessageBox.Show("No Items in List..", "Error");
                textBox3.Clear();
            }
            else
            {
                int sum = 0;
                for (int i = 0; i < size; i++)
                {
                    sum += int.Parse(listBox1.Items[i].ToString());
                }
                textBox3.Text = (sum / size).ToString();
            }
        }
    }
}
