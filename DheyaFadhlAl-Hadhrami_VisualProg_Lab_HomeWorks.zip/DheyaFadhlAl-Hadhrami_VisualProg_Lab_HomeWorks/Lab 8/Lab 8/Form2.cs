﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Lab_8
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            textBox2.ReadOnly = true;
        }

        Stack<string> undoStack = new Stack<string>();
        const int MAX_UNDO_COUNT = 10;
        string cpText = "";

        private void SaveState()
        {
            if (undoStack.Count >= MAX_UNDO_COUNT)
            {
                undoStack.Pop();
            }
            undoStack.Push(textBox1.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveState();

            if (textBox1.SelectedText != "")
            {
                cpText = textBox1.SelectedText;
            }
            else
            {
                if (textBox1.Text != "")
                {
                    cpText = textBox1.Text;
                }
                else
                {
                MessageBox.Show("The TextBox Is Empty..", "Exception");
                textBox1.Focus();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SaveState();

            if (textBox1.SelectedText != "")
            {
                cpText = textBox1.SelectedText;
                textBox1.SelectedText = "";
            }
            else
            {
                if (textBox1.Text != "")
                {
                    cpText = textBox1.Text;
                    textBox1.Clear();
                }
                else
                {
                    MessageBox.Show("The TextBox Is Empty..", "Exception");
                    textBox1.Focus();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SaveState();

            if (cpText != "")
            {
                textBox2.Clear();
                textBox2.Text = cpText;
            }
            else
            {
                MessageBox.Show("Clipboard Is Empty..", "Exception");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (undoStack.Count > 0)
            {
                textBox1.Text = undoStack.Pop();
            }
            else
            {
                MessageBox.Show("No more undo operations available.", "Undo");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
