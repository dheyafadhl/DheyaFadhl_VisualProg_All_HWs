﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAllLength_Click(object sender, EventArgs e)
        {
            txtAllLength.Text = txtAllText.Text.Length.ToString();
        }

        private void btnSelectedLength_Click(object sender, EventArgs e)
        {
            if (txtAllText.SelectedText.Length > 0)
            {
                txtSelectedLength.Text = txtAllText.SelectedText.Trim().Length.ToString();
            }
            else
            {
                MessageBox.Show("Select The Text..", "Error");
                txtSelectedLength.Text = "";
            }
        }

        private void btnWordsCount_Click(object sender, EventArgs e)
        {
            string[] Words = txtAllText.Text.Trim().Split(' ');
            txtWordsCount.Text = (Words.Length - 1).ToString();
        }

        private void btnDelSelected_Click(object sender, EventArgs e)
        {
            if (txtAllText.SelectedText.Length > 0)
            {
                txtAllText.SelectedText = "";
            }
            else
            {
                MessageBox.Show("Select The Text..", "Error");
            }

        }

        private void btnUnSelect_Click(object sender, EventArgs e)
        {
            if (txtAllText.SelectedText.Length > 0)
            {
                txtAllText.SelectionLength = 0;
            }
            else
            {
                MessageBox.Show("No Found Text is Selected..", "Error");
            }
        }


        private void btnCopy_Click(object sender, EventArgs e)
        {
            if (txtAllText.SelectedText.Length > 0)
            {
                Clipboard.SetText(txtAllText.SelectedText);
            }
            else
            {
                MessageBox.Show("No Found Text is Selected..", "Error");
            }
        }

        private void btnMove_Click(object sender, EventArgs e)
        {
            if (txtAllText.SelectedText.Length > 0)
            {
                Clipboard.SetText(txtAllText.SelectedText);
                txtAllText.SelectedText = "";
            }
            else
            {
                MessageBox.Show("No Found Text is Selected..", "Error");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtAllText.Clear();
        }

        private void btnAllCharLength_Click(object sender, EventArgs e)
        {
            int Count = 0;
            for (int i = 0; i < txtAllText.Text.Length; i++)
            {
                if (txtAllText.Text[i] != ' ')
                {
                    Count++;
                }
            }
            MessageBox.Show(Count.ToString(), "طول النص بدون فراغات");
        }

        private void btnAllSelectedCharLength_Click(object sender, EventArgs e)
        {
            int Count = 0;
            for (int i = 0; i < txtAllText.SelectedText.Length; i++)
            {
                if (txtAllText.SelectedText[i] != ' ')
                {
                    Count++;
                }
            }
            MessageBox.Show(Count.ToString(), "طول النص المحدد بدون فراغات");
        }

        private void btnReplace_Click(object sender, EventArgs e)
        {
            if (txtAllText.SelectedText.Length > 0)
            {
                if (txtNewText.Text != "")
                {
                    txtAllText.SelectedText = txtNewText.Text;
                }
                else
                {
                    MessageBox.Show("Insert The New Text..", "Error");
                    txtSearchText.Focus();
                }
            }
            else
            {
                MessageBox.Show("Select The Text To Replace it..", "Error");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtSearchText.Text != "")
            {
                int index = txtAllText.Text.IndexOf(txtSearchText.Text, 0);
                if (index > -1)
                {
                    txtAllText.SelectionStart = index;
                    txtAllText.SelectionLength = txtSearchText.Text.Length;
                    txtAllText.Focus();
                }
                else
                {
                    MessageBox.Show("Not Found..", "Sorry");
                }
            }
            else
            {
                MessageBox.Show("Insert Text To Search..", "Error");
                txtSearchText.Focus();
            }
        }

        private void btnSearchNext_Click(object sender, EventArgs e)
        {
            if (txtSearchText.Text.Trim() != "")
            {
                int index = txtAllText.Text.IndexOf(txtSearchText.Text, txtAllText.SelectionStart + txtAllText.SelectionLength);

                if (index > -1)
                {
                    txtAllText.Focus();
                    txtAllText.Select(index, txtSearchText.Text.Length);
                }
                else
                {
                    MessageBox.Show("Not Found..", "Sorry");
                }
            }
            else
            {
                MessageBox.Show("Insert Text To Search..", "Error");
                txtSearchText.Focus();
            }
        }

        private void btnSearchPrevious_Click(object sender, EventArgs e)
        {
            if (txtSearchText.Text.Trim() != "")
            {
                int index = txtAllText.Text.LastIndexOf(txtSearchText.Text, txtAllText.SelectionStart - txtAllText.SelectionLength);

                if (index > -1)
                {
                    txtAllText.Focus();
                    txtAllText.Select(index, txtSearchText.Text.Length);
                }
                else
                {
                    MessageBox.Show("Not Found..", "Sorry");
                }
            }
            else
            {
                MessageBox.Show("Insert Text To Search..", "Error");
                txtSearchText.Focus();
            }
        }

        private void btnPaste_Click(object sender, EventArgs e)
        {
            txtPasteBox.Text = Clipboard.GetText();
        }

        private void btnUndo_Click(object sender, EventArgs e)
        {
            if (txtAllText.CanUndo || txtPasteBox.CanUndo)
            {
                txtAllText.Undo();
                txtPasteBox.Undo();
            }
            else
            {
                MessageBox.Show("Cant Do Undo..", "Error");
            }
        }


        private void btnShowSelectedWordChars_Click(object sender, EventArgs e)
        {
            if (txtAllText.Text.Length > 0)
            {
                listBoxChar.Items.Clear();
                string SelectedTxt = txtAllText.SelectedText.Trim();
                char[] chars = SelectedTxt.ToCharArray();
            
                for (int i = 0; i < chars.Length; i++)
                {
                    listBoxChar.Items.Add(chars[i]);
                }
            }
            else
            {
                listBoxChar.Items.Clear();
                listBoxWords.Items.Clear();
                MessageBox.Show("Select Text..", "Error");
            }
        }

        private void btnShowSelectedTextWords_Click(object sender, EventArgs e)
        {
            if (txtAllText.Text.Length > 0)
            {
                listBoxWords.Items.Clear();
                string[] SelectedTxt = txtAllText.SelectedText.Split(' ');

                for (int i = 0; i < SelectedTxt.Length; i++)
                {
                        listBoxWords.Items.Add(SelectedTxt[i]);
                }
            }
            else
            {
                listBoxWords.Items.Clear();
                listBoxChar.Items.Clear();
                MessageBox.Show("Select Text..", "Error");
            }
        }

        private void btnSearchPattern_Click(object sender, EventArgs e)
        {
            if (txtSearchPattren.Text != "")
            {
                string[] strings = txtSearchPattren.Text.Split(' ');
                int size = strings.Length - 1;

                int StartIndex = txtAllText.Text.IndexOf(txtSearchPattren.Text, 0);
                int EndIndex = txtAllText.Text.IndexOf(strings[size], 0) + strings[size].Length;

                txtAllText.Select(StartIndex, txtSearchPattren.Text.Length);
                txtAllText.Focus();
            }
            else
            {
                MessageBox.Show("Insert Text To Search..", "Error");
                txtSearchText.Focus();
            }
        }

    }
}
