﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Lab6
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            this.AutoSize = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Bitmap bmp = new Bitmap(this.Width, this.Height);

            int x, y;
            for (y = 10; y < this.Height - 50; y++)
            {

                for (x = 10; x < this.Width - 50; x++)
                {
                    bmp.SetPixel(x, y, Color.Red);
                }
            }
            pictureBox1.Image = bmp;
            //pictureBox1.BackgroundImage = bmp;

            this.BackgroundImage = bmp;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                pictureBox1.Image = null;
            }
            catch (Exception)
            {
                MessageBox.Show("Picture Box Is Empty..", "Error");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
