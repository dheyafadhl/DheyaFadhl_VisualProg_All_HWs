﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Interval = 5;
            timer1.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }
        int s = -1, m = 0, h = 0, y = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            s++;

            if (s > 9)
                labSec.Text = s.ToString();
            else
                labSec.Text = "0" + s.ToString();


            if (s > 59)
            {
                s = 0;
                m++;
                labSec.Text = "0" + s.ToString();
                if (m > 9)
                    labMin.Text = m.ToString();
                else 
                    labMin.Text = "0" + m.ToString();
            }

                
            if (m > 59)
            {
                m = 0;
                h++;
                labMin.Text = "0" + m.ToString();

                if (h > 9)
                    labHour.Text = h.ToString();
                else
                    labHour.Text = "0" + h.ToString();
            }

            if (h > 23)
            {
                h = 0;
                y++;
                labHour.Text = "0" + h.ToString();

                if (y > 9)
                    labDay.Text = y.ToString();
                else
                    labDay.Text = "0" + y.ToString();
            }
        }
    }
}
