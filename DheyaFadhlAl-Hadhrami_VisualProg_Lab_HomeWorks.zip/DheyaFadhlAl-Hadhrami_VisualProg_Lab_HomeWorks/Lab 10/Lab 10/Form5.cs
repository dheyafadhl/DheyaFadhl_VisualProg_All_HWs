﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Lab_10
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            LoadDetails();
        }

        int number;
        void LoadDetails()
        {
            number = Form3.st[Form4.index].GetNumber();
            numericUpDown1.Value = number;
            textBox1.Text = Form3.st[Form4.index].GetName();
            dateTimePicker1.Value = Convert.ToDateTime(Form3.st[Form4.index].GetBirthday());
            pictureBox1.Image = Image.FromFile(Form3.st[Form4.index].GetImgPath());
        }


        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            openFileDialog1.Filter = "ImageFile|*.jpg;*.png;*.ico;*.bmp";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            if ((MessageBox.Show("Are You Sure..", "Close", MessageBoxButtons.OKCancel)) == DialogResult.OK)
            {
                Close();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() != ""){
                if (!Form3.CheckNumber(Convert.ToInt32(numericUpDown1.Value), number))
                {
                    MessageBox.Show("The number already exists..", "Error", MessageBoxButtons.OK);
                    numericUpDown1.Focus();
                }
                else
                {
                    Form3.st[Form4.index].SetNumber(Convert.ToInt32(numericUpDown1.Value));
                    Form3.st[Form4.index].SetName(textBox1.Text.Trim());
                    Form3.st[Form4.index].SetBirthday(dateTimePicker1.Value.ToString());
                    if (File.Exists(openFileDialog1.FileName))
                    {
                        Form3.st[Form4.index].SetImgPath(openFileDialog1.FileName);
                    }

                    Close();
                }
            }
            else
            {
                MessageBox.Show("Insert Name..", "Error", MessageBoxButtons.OK);
            }
        }
    }
}
