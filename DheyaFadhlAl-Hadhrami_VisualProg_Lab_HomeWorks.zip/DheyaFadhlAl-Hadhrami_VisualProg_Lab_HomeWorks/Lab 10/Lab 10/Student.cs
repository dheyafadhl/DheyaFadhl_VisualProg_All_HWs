﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_10
{
    public class Student
    {
        private int num;
        private string name;
        private string birthday;
        private string imgPath;

        public void SetNumber (int n){ this.num = n; }
        public void SetName (string n) { this.name = n; }
        public void SetBirthday (string b) { this.birthday = b; }
        public void SetImgPath (string p) {  this.imgPath = p; }


        public int GetNumber() => num;
        public string GetName() => name;
        public string GetBirthday() => birthday;
        public string GetImgPath() => imgPath;
    }
}
