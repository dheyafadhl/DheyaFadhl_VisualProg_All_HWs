﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_10
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            LoadStudents();
        }

        void LoadStudents()
        {
            try
            {
                for (int i = 0; i < Form3.Count; i++)
                {
                    listBox1.Items.Add(Form3.st[i].GetNumber());
                    listBox2.Items.Add(Form3.st[i].GetName());
                    listBox3.Items.Add(Form3.st[i].GetBirthday());

                    listBox1.SelectedIndex = i;
                }
                pictureBox1.Image = Image.FromFile(Form3.st[Form3.Count - 1].GetImgPath());
            }
            catch
            {
                MessageBox.Show("Empty DataBase..", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
            }
        }

        public static int index = -1;
        private void listBox_SelectedIndexChange(object sender, EventArgs e)
        {
            if (((ListBox)sender).SelectedIndex != -1)
            {
                index = listBox1.SelectedIndex = listBox2.SelectedIndex = listBox3.SelectedIndex = ((ListBox)sender).SelectedIndex;
                pictureBox1.Image = Image.FromFile(Form3.st[index].GetImgPath());
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            pictureBox1.Image = null;

            LoadStudents();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                Form5 f = new Form5();
                f.ShowDialog();
                listBox1.Items[index] = Form3.st[index].GetNumber();
                listBox2.Items[index] = Form3.st[index].GetName();
                listBox3.Items[index] = Form3.st[index].GetBirthday();

                pictureBox1.Image = Image.FromFile(Form3.st[index].GetImgPath());
            }
        }

        
    }
}
