﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_10
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        Form3 FormAdd;
        Form4 FormShow;

        private void addStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (FormAdd == null || FormAdd.IsDisposed)
            {
                FormAdd = new Form3();
                FormAdd.Show();
            }
            else
            {
                FormAdd.BringToFront();
                FormAdd.Focus();
            }
        }

        private void showStudentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (FormShow == null || FormShow.IsDisposed)
            {
                FormShow = new Form4();
                FormShow.Show();
            }
            else
            {
                FormShow.BringToFront();
                FormShow.Focus();
            }
            
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.Count - 1 > 0) 
                Application.OpenForms[Application.OpenForms.Count - 1].Close();
        }

        private void closeAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int count = Application.OpenForms.Count;
            if (count > 0)
            {
                for (int i = 0; i < count - 1; i++)
                {
                    Application.OpenForms[i].Close();
                }
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
