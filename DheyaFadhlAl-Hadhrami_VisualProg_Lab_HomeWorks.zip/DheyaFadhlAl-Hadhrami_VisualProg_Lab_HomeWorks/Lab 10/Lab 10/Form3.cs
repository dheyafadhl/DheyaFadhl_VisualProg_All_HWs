﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_10
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        public static Student[] st = new Student[100];
        public static int Count = 0;

        bool isChoceImage = false;

        public static bool CheckNumber(int num)
        {
            for (int i = 0; i < Count; i++)
            {
                if (st[i].GetNumber() == num)
                {
                    return false;
                }
            }
            return true;
        }
        public static bool CheckNumber(int num, int without)
        {
            for (int i = 0; i < Count; i++)
            {
                if (st[i].GetNumber() == num && st[i].GetNumber() != without)
                {
                    return false;
                }
            }
            return true;
        }
        private void Form3_Load(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) &&
                !((e.KeyChar >= 'A' && e.KeyChar <= 'Z') ||
                (e.KeyChar >= 'a' && e.KeyChar <= 'z') ||
                (e.KeyChar >= 'ء' && e.KeyChar <= 'ي') ||
                (e.KeyChar == ' ') ||
                (e.KeyChar == 8)))
            {
                e.Handled = true; 
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (Count < 100)
            {
                if (isChoceImage && textBox1.Text != "")
                {
                    if (!CheckNumber(Convert.ToInt32(numericUpDown1.Value)))
                    {
                        MessageBox.Show("The number already exists..", "Error", MessageBoxButtons.OK);
                        numericUpDown1.Focus();
                    }
                    else
                    {
                        st[Count] = new Student();
                        st[Count].SetNumber(Convert.ToInt32(numericUpDown1.Value));
                        st[Count].SetName(textBox1.Text.Trim());
                        st[Count].SetBirthday(dateTimePicker1.Value.ToString());
                        st[Count].SetImgPath(openFileDialog1.FileName);

                        Count++;
                        numericUpDown1.Value = 0;
                        textBox1.Clear();
                        dateTimePicker1.Value = DateTime.Now;
                        pictureBox1.Image = null;

                        isChoceImage = false;

                        MessageBox.Show("Added Student", "Successfuly", MessageBoxButtons.OK);
                    }
                }
                else
                {
                    MessageBox.Show("Compelete All Details", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Student Count is Full..", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if ((MessageBox.Show("Are You Sure..", "Close", MessageBoxButtons.OKCancel)) == DialogResult.OK)
            {
                Close();
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            openFileDialog1.Filter = "ImageFiles|*.jpg;*.png;*.ico;*.bmp";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
                isChoceImage = true;
            }
        }

    }
}
