﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("jpg");
            comboBox1.Items.Add("png");
            comboBox1.Items.Add("ico");
            comboBox1.Items.Add("txt");

            comboBox1.SelectedIndex = 0;

            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;

            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            
        }

        private void driveListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dirListBox1.Path = driveListBox1.Drive;
        }

        private void dirListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            fileListBox1.Path = dirListBox1.Path;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            fileListBox1.Pattern = "*." + comboBox1.Text.Trim();
        }

        private void fileListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            labPath.Text = fileListBox1.Path + "\\" + fileListBox1.FileName;
            labName.Text = Path.GetFileName(labPath.Text);
            labFormat.Text = Path.GetExtension(labPath.Text);

            if (labFormat.Text == "txt")
            {
                richTextBox1.Text = File.ReadAllText(labPath.Text);
                pictureBox1.Image = null;
            }
            else
            {
                pictureBox1.Image = Image.FromFile(labPath.Text);
                richTextBox1.Clear();
            }
        }
    }
}
